# multi-projects-portfolio

Colección de 5 proyectos listos para desarrollo y despliegue con Docker.

Contenido:
1. api-usuarios (Node.js + Express + MongoDB)
2. sistema-inventario (Java Spring Boot + MySQL)
3. portal-noticias (Python Django + SQLite)
4. chat-realtime (Node.js + Socket.io + Redis)
5. api-analisis (Python FastAPI + SQLite)

Lea el README dentro de cada proyecto para instrucciones de ejecución.
