# Chat realtime (Node + Socket.io + Redis)

Ejecutar:
1. Levanta Redis con docker-compose.
2. npm install
3. node index.js
