const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const io = new Server();
const app = express();
const server = http.createServer(app);
io.attach(server);

io.on('connection', (socket) => {
  console.log('user connected', socket.id);
  socket.on('msg', (data) => {
    // broadcast to all
    io.emit('msg', data);
  });
  socket.on('disconnect', ()=> console.log('disconnected', socket.id));
});

server.listen(4000, ()=> console.log('Chat server on 4000'));
