# Portal Noticias (Django)

Instrucciones rápidas:
1. Crear entorno virtual: python -m venv venv && source venv/bin/activate
2. Instalar requirements: pip install -r requirements.txt
3. Ejecutar migraciones: python manage.py migrate
4. Levantar servidor: python manage.py runserver 8000
