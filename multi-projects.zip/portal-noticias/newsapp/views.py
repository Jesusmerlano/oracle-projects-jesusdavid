from django.http import JsonResponse, HttpResponse
from .models import Article
def index(request):
    return HttpResponse('Portal Noticias - OK')
def articles_api(request):
    items = list(Article.objects.values('id','title','published','created'))
    return JsonResponse(items, safe=False)
