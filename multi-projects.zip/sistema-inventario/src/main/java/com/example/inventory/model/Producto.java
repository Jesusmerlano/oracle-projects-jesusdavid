package com.example.inventory;

import jakarta.persistence.*;

@Entity
public class Producto {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long id;
  private String nombre;
  private Integer stock;
  private Double precio;
  // getters y setters
  public Long getId(){return id;} public void setId(Long id){this.id=id;}
  public String getNombre(){return nombre;} public void setNombre(String n){this.nombre=n;}
  public Integer getStock(){return stock;} public void setStock(Integer s){this.stock=s;}
  public Double getPrecio(){return precio;} public void setPrecio(Double p){this.precio=p;}
}
