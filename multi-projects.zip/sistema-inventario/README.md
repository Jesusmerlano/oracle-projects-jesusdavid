# Sistema Inventario (Spring Boot + MySQL)

Ejecutar:
1. Levanta MySQL con `docker-compose up -d`.
2. Ejecuta `mvn -f pom.xml spring-boot:run` desde esta carpeta.
3. API endpoints básicos en /api/productos y /api/productos/{id}/movimientos

Nota: proyecto es un skeleton listo para compilar con Maven.
