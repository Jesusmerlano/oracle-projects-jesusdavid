from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import sqlite3

app = FastAPI()

class DataInput(BaseModel):
    values: list[float]

@app.post('/api/stats')
def stats(data: DataInput):
    s = pd.Series(data.values)
    return {'count': int(s.count()), 'mean': float(s.mean()), 'std': float(s.std())}
