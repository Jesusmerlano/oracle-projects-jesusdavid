# API Análisis (FastAPI + SQLite)

Ejecutar:
1. python -m venv venv && source venv/bin/activate
2. pip install -r requirements.txt
3. uvicorn main:app --reload --port 8002
