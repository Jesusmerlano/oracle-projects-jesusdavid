const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();
const app = express();
app.use(express.json());

const MONGO = process.env.MONGO_URL || 'mongodb://root:example@localhost:27017/?authSource=admin';

mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('Mongo connected'))
  .catch(err => console.error('Mongo connect error', err));

const userSchema = new mongoose.Schema({ name: String, email: { type: String, unique: true } }, { timestamps: true });
const User = mongoose.model('User', userSchema);

// CRUD
app.get('/api/users', async (req, res) => {
  const users = await User.find().lean();
  res.json(users);
});

app.post('/api/users', async (req, res) => {
  try {
    const u = new User(req.body);
    await u.save();
    res.json(u);
  } catch(err) { res.status(400).json({ error: err.message }); }
});

app.get('/api/users/:id', async (req, res) => {
  const u = await User.findById(req.params.id);
  if(!u) return res.status(404).send('Not found');
  res.json(u);
});

app.put('/api/users/:id', async (req, res) => {
  const u = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(u);
});

app.delete('/api/users/:id', async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.status(204).send();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('API Usuarios listening on', PORT));
