# API Usuarios (Node.js + Express + MongoDB)

Instalación y ejecución:
1. Copia `.env.example` como `.env` y ajusta variables.
2. Levanta `docker-compose up -d` para Mongo.
3. Desde esta carpeta:
   ```bash
   npm install
   npm run dev
   ```
Endpoints principales:
- GET /api/users
- POST /api/users  { name, email }
- GET /api/users/:id
- PUT /api/users/:id
- DELETE /api/users/:id
